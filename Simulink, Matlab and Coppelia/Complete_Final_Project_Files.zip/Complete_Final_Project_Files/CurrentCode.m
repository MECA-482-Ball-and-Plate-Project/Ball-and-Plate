clear all
close all
clc
coppelia=remApi('remoteApi');
coppelia.simxFinish(-1);
clientID=coppelia.simxStart('127.0.0.1',19999,true,true,5000,5);
if (clientID>-1)  
     disp('Connected to remote API server');
     
     set_param('ball_and_plate','SimulationCommand','start') 
    
     %joints
     h=[0,0];
        [r,h(1)]=coppelia.simxGetObjectHandle(clientID, 'RotateY0',coppelia.simx_opmode_blocking);
        [r,h(2)]=coppelia.simxGetObjectHandle(clientID, 'RotateX',coppelia.simx_opmode_blocking);
       
     while true
     [res,retInts,retFloats,retStrings,retBuffer]=coppelia.simxCallScriptFunction(clientID,'Cam',coppelia.sim_scripttype_childscript,'CoordCalc',[],[],[],'',coppelia.simx_opmode_blocking);
     xcoord=retFloats(1);
     ycoord=retFloats(2);
     
     r_matx=xcoord;
     set_param('ball_and_plate/Constant','Value',num2str(r_matx));
     pause(.01);
    
     r_maty=ycoord;
     set_param('ball_and_plate/Constant2','Value',num2str(r_maty));
     pause(.01);
     
     thetax=get_param('ball_and_plate/To Workspace','RuntimeObject');
     angleX1= (thetax.InputPort(1).Data * 10000);
     
     thetay=get_param('ball_and_plate/To Workspace1','RuntimeObject');
     angleY1= (thetay.InputPort(1).Data * 10000);
     
     coppelia.simxSetJointTargetPosition(clientID,h(2),angleX1,coppelia.simx_opmode_streaming)
     coppelia.simxSetJointTargetPosition(clientID,h(1),angleY1,coppelia.simx_opmode_streaming)
     
     
     end
else
      disp('Failed connecting to remote API server');
end
    coppelia.delete(); % call the destructor!
    
    disp('Program ended');