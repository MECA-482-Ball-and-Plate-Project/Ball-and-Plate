clear all
close all
clc
coppelia=remApi('remoteApi');
coppelia.simxFinish(-1);
clientID=coppelia.simxStart('127.0.0.1',19999,true,true,5000,5);
if (clientID>-1)  
     disp('Connected to remote API server');
     %joint pos
     joint_pos1=[-2*pi/3,0,0,0,pi/4,0];
     joint_pos2=[0,-pi/4,pi/2,0,0,0];
     joint_pos3=[0,0,0,0,0,0];
     %joints
     h=[0,0]
        [r,h(1)]=coppelia.simxGetObjectHandle(clientID, 'RotateY0',coppelia.simx_opmode_blocking);
        [r,h(2)]=coppelia.simxGetObjectHandle(clientID, 'RotateX',coppelia.simx_opmode_blocking);
        
        while true
            for i=1:6
            coppelia.simxSetJointTargetPosition(clientID,h(1),joint_pos1(1),coppelia.simx_opmode_streaming)
            end
            pause(10);
            
              for i=1:6
            coppelia.simxSetJointTargetPosition(clientID,h(1),joint_pos2(1),coppelia.simx_opmode_streaming)
            end
            pause(10);
            
              for i=1:6
            coppelia.simxSetJointTargetPosition(clientID,h(1),joint_pos3(1),coppelia.simx_opmode_streaming)
            end
            pause(10);
        end
else
      disp('Failed connecting to remote API server');
end
    coppelia.delete(); % call the destructor!
    
    disp('Program ended');